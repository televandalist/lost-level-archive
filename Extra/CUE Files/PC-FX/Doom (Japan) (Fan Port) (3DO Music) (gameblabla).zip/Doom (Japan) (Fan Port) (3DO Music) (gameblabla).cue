FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 01).bin" BINARY
  TRACK 01 AUDIO
    INDEX 01 00:00:00
FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 02).bin" BINARY
  TRACK 02 MODE1/2048
    INDEX 00 00:00:00
    INDEX 01 00:02:00
FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 03).bin" BINARY
  TRACK 03 AUDIO
    INDEX 00 00:00:00
    INDEX 01 00:02:00
FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 04).bin" BINARY
  TRACK 04 AUDIO
    INDEX 01 00:00:00
FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 05).bin" BINARY
  TRACK 05 AUDIO
    INDEX 01 00:00:00
FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 06).bin" BINARY
  TRACK 06 AUDIO
    INDEX 01 00:00:00
FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 07).bin" BINARY
  TRACK 07 AUDIO
    INDEX 01 00:00:00
FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 08).bin" BINARY
  TRACK 08 AUDIO
    INDEX 01 00:00:00
FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 09).bin" BINARY
  TRACK 09 AUDIO
    INDEX 01 00:00:00
FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 10).bin" BINARY
  TRACK 10 AUDIO
    INDEX 01 00:00:00
FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 11).bin" BINARY
  TRACK 11 AUDIO
    INDEX 01 00:00:00
FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 12).bin" BINARY
  TRACK 12 AUDIO
    INDEX 01 00:00:00
FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 13).bin" BINARY
  TRACK 13 AUDIO
    INDEX 01 00:00:00
FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 14).bin" BINARY
  TRACK 14 AUDIO
    INDEX 01 00:00:00
FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 15).bin" BINARY
  TRACK 15 AUDIO
    INDEX 01 00:00:00
FILE "Doom (Japan) (Fan Port) (3DO Music) (gameblabla) (Track 16).bin" BINARY
  TRACK 16 AUDIO
    INDEX 01 00:00:00
