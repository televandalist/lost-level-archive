FILE "IRRÉEL (v0.018) (XL2) (RA Compatible) (Track 1).iso" BINARY
  TRACK 01 MODE1/2048
      INDEX 01 00:00:00
      POSTGAP 00:02:00
FILE "IRRÉEL (v0.018) (XL2) (RA Compatible) (Track 2).wav" WAVE
  TRACK 02 AUDIO
    PREGAP 00:02:00
    INDEX 01 00:00:00
FILE "IRRÉEL (v0.018) (XL2) (RA Compatible) (Track 3).wav" WAVE
  TRACK 03 AUDIO
    INDEX 01 00:00:00
FILE "IRRÉEL (v0.018) (XL2) (RA Compatible) (Track 4).wav" WAVE
  TRACK 04 AUDIO
    INDEX 01 00:00:00
FILE "IRRÉEL (v0.018) (XL2) (RA Compatible) (Track 5).wav" WAVE
  TRACK 05 AUDIO
    INDEX 01 00:00:00
