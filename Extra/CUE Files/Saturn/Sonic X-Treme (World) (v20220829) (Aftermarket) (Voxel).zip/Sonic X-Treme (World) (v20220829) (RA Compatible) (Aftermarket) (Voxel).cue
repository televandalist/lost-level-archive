FILE "Sonic X-Treme (World) (v20220829) (RA Compatible) (Aftermarket) (Voxel) (Track 01).iso" BINARY
  TRACK 01 MODE1/2048
      INDEX 01 00:00:00
      POSTGAP 00:02:00
FILE "Sonic X-Treme (World) (v20220829) (RA Compatible) (Aftermarket) (Voxel) (Track 02).wav" WAVE
  TRACK 02 AUDIO
    PREGAP 00:02:00
    INDEX 01 00:00:00
FILE "Sonic X-Treme (World) (v20220829) (RA Compatible) (Aftermarket) (Voxel) (Track 03).wav" WAVE
  TRACK 03 AUDIO
    INDEX 01 00:00:00
FILE "Sonic X-Treme (World) (v20220829) (RA Compatible) (Aftermarket) (Voxel) (Track 04).wav" WAVE
  TRACK 04 AUDIO
    INDEX 01 00:00:00
FILE "Sonic X-Treme (World) (v20220829) (RA Compatible) (Aftermarket) (Voxel) (Track 05).wav" WAVE
  TRACK 05 AUDIO
    INDEX 01 00:00:00
FILE "Sonic X-Treme (World) (v20220829) (RA Compatible) (Aftermarket) (Voxel) (Track 06).wav" WAVE
  TRACK 06 AUDIO
    INDEX 01 00:00:00
FILE "Sonic X-Treme (World) (v20220829) (RA Compatible) (Aftermarket) (Voxel) (Track 07).wav" WAVE
  TRACK 07 AUDIO
    INDEX 01 00:00:00
FILE "Sonic X-Treme (World) (v20220829) (RA Compatible) (Aftermarket) (Voxel) (Track 08).wav" WAVE
  TRACK 08 AUDIO
    INDEX 01 00:00:00
FILE "Sonic X-Treme (World) (v20220829) (RA Compatible) (Aftermarket) (Voxel) (Track 09).wav" WAVE
  TRACK 09 AUDIO
    INDEX 01 00:00:00
