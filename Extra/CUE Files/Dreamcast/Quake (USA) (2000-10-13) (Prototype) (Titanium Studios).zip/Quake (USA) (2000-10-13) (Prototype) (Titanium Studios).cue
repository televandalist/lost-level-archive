REM SINGLE-DENSITY AREA
FILE "Quake (USA) (2000-10-13) (Prototype) (Titanium Studios) (Track 1).bin" BINARY
  TRACK 01 MODE1/2352
    INDEX 01 00:00:00
FILE "Quake (USA) (2000-10-13) (Prototype) (Titanium Studios) (Track 2).bin" BINARY
  TRACK 02 AUDIO
    INDEX 00 00:00:00
    INDEX 01 00:02:00
REM HIGH-DENSITY AREA
FILE "Quake (USA) (2000-10-13) (Prototype) (Titanium Studios) (Track 3).bin" BINARY
  TRACK 03 MODE1/2352
    INDEX 01 00:00:00
FILE "Quake (USA) (2000-10-13) (Prototype) (Titanium Studios) (Track 4).bin" BINARY
  TRACK 04 AUDIO
    INDEX 00 00:00:00
    INDEX 01 00:02:00
FILE "Quake (USA) (2000-10-13) (Prototype) (Titanium Studios) (Track 5).bin" BINARY
  TRACK 05 MODE1/2352
    INDEX 00 00:00:00
    INDEX 01 00:03:00
