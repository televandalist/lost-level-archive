FILE "PSXFunkin' - Sunday Night Suicide (v20211126) (Lord Scout).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
