FILE "PSXFunkin' - Duo Pack - BF Ugh and Angrier Senpai (v0.9.2) (LordScout).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
