FILE "PSXFunkin' - Loggo's Halloween DX (v20221223) (Tomscop).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
