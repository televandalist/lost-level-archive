FILE "PSXFunkin' - Vs. Dave and Bambi - Golden Apple (v1.1) (DreamcastNick).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
