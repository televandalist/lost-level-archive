FILE "Baroque - Yuganda Mousou (Japan) (En) (v1.02) (Plissken) (Track 1).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
FILE "Baroque - Yuganda Mousou (Japan) (En) (v1.02) (Plissken) (Track 2).bin" BINARY
  TRACK 02 AUDIO
    INDEX 00 00:00:00
    INDEX 01 00:02:00
