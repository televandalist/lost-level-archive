FILE "PSXFunkin' - PSXGarcello (v1.1) (IgorSou3000).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
