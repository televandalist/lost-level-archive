FILE "PSXFunkin' - Gambino Week (v20210831) (LordScout).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
