FILE "PSXFunkin' - Beach Brother (v20220405) (victor179).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
