FILE "PSXFunkin' - Friday Night Wumpin' (v1.1.1) (Lord Scout).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
