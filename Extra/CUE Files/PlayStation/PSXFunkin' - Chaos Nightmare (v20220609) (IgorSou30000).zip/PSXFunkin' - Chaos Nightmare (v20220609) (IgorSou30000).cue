FILE "PSXFunkin' - Chaos Nightmare (v20220609) (IgorSou30000).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
