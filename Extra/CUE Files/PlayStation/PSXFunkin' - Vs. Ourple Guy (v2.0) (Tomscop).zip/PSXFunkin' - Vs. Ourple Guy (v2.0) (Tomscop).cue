FILE "PSXFunkin' - Vs. Ourple Guy (v2.0) (Tomscop).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
