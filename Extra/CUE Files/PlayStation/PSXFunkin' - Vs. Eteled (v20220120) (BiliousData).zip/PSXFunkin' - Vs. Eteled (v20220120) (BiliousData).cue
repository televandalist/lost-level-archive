FILE "PSXFunkin' - Vs. Eteled (v20220120) (BiliousData).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
