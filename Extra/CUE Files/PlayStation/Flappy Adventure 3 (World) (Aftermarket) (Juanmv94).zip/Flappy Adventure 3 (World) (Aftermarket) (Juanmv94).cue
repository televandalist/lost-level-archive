FILE "Flappy Adventure 3 (World) (Aftermarket) (Juanmv94).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
