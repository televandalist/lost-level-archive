FILE "PSXFunkin' - Vs. Imposter (v4.0) (Tomscop) (Disc 1).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
