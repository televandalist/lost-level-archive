FILE "Resident Evil 3 - Nemesis (USA) (Ru) (v1.0) (kalash49).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
