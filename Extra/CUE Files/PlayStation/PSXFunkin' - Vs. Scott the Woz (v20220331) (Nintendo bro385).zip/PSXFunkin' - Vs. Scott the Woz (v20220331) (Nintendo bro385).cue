FILE "PSXFunkin' - Vs. Scott the Woz (v20220331) (Nintendo bro385).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
