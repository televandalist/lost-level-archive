FILE "PSXFunkin' - Alex the Artic Funk (v1.3) (CatOnVenus).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
