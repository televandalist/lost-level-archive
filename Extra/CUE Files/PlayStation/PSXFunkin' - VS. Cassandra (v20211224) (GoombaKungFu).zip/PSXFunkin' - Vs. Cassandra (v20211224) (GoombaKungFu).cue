FILE "PSXFunkin' - Vs. Cassandra (v20211224) (GoombaKungFu).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
