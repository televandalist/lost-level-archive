FILE "PSXFunkin' - The Amazing Grace - Rotten-Smoothie (v20241031) (DreamcastNick).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
