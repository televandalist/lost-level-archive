FILE "PSXFunkin' - Vs. Sonic.EXE (v1.5.2) (LordScout).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
