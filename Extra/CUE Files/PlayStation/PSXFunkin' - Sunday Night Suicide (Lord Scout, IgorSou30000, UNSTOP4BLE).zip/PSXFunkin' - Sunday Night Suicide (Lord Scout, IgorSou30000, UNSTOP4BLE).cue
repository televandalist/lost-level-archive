FILE "PSXFunkin' - Sunday Night Suicide (Lord Scout, IgorSou30000, UNSTOP4BLE).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
