FILE "PSXFunkin' - Baldi's Basics in Funkin' (v20211109) (DreamcastNick).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
