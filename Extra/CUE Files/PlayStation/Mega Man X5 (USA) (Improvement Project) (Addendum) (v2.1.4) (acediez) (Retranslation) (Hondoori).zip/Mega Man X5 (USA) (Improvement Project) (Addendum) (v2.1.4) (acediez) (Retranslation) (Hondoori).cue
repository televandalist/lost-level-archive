FILE "Mega Man X5 (USA) (Improvement Project) (Addendum) (v2.1.4) (acediez) (Retranslation) (Hondoori).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
