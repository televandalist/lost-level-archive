FILE "PSXFunkin' - VS. v-tan (v2021-10-22) (BiliousData).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
